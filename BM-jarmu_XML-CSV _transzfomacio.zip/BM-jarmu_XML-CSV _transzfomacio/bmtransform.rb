#!/usr/bin/ruby

require 'rubygems'
gem 'nokogiri'
require 'nokogiri'

doc = Nokogiri::XML(File.open(ARGV[0]))

output = File.open(ARGV[0] + ".csv", "w")
output.write( "\"GYARTMANY_NEV\";\"GYARTMANY_KOD\";\"TIPUS_NEV\";\"TIPUS_KOD\";\"FAJTA_NEV\";\"FAJTA_KOD\"\n")
gyLista = doc.css("GyLista")

gyLista.each do |gyartmany|
	gyartmanyNev = gyartmany.css("Gyartmany Nev")
	gyartmanyKod = gyartmanyNev.first().attributes['Kod']
	
	tipusok = gyartmany.css("Tipus")
	tipusok.each do |tipus|
		tipusNev = tipus.css("Nev")
		tNev = tipusNev.first().content()
		tKod = tipusNev.first().attributes['Kod']
		
		fajta = tipus.css("Fajta")
		fajta.each do |f|
			fKod = f.attributes['Kod']
			fNev = f.content()

			output.write( "\"" + gyartmanyNev.first().content() + "\";\"" + gyartmanyKod +
				      "\";\"" + tNev + "\";\"" + tKod + "\";\"" + fNev + "\";\"" + fKod + "\"\n")
		end
	end
end

output.close
